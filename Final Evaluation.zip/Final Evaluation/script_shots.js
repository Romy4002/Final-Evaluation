var boot = "https://www.youtube.com/embed/vpAJ0s5S2t0"
var html = "https://www.youtube.com/embed/qz0aGYrrlhU"
var python = "https://www.youtube.com/embed/_uQrJ0TkZlc"
var java = "https://www.youtube.com/embed/W6NZfCO5SIk"

function coursefunc(course) {
    document.getElementById("myframe").src = course;
}

var btxt = "BOOTSTRAP ONE-SHOT"
var htxt = "HTML ONE-SHOT"
var ptxt = "PYTHON ONE-SHOT"
var jtxt = "JAVASCRIPT ONE-SHOT"

function headsfunc(heads) {
    document.getElementById("allheads").innerHTML = heads
}